from langchain_community.llms import Ollama
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory

llm = Ollama(model="llama3")

memory = ConversationBufferMemory(return_messages=True)

conversation = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=False
)

print("🤖 Chatbot ready! Type 'exit' to quit, or 'show memory' to see stored history.\n")

while True:
    user_input = input("You: ")
    if user_input.lower() in ["exit", "quit", "bye"]:
        print("🤖 Bot: Goodbye! 👋")
        break
    
    if user_input.lower() == "show memory":
        print("\n📝 Stored conversation so far:\n")
        for msg in memory.load_memory_variables({})["history"]:
            print(msg)
        print("\n")
        continue

    response = conversation.invoke(user_input)
    print("🤖 Bot:", response["response"])
